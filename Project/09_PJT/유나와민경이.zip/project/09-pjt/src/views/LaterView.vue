<template>
  <div>
    <h1>나중에 볼 영상</h1>
  </div>
</template>

<script setup></script>

<style scoped></style>
