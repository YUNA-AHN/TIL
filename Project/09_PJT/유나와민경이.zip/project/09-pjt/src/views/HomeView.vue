<template>
  <div>
    <h1>홈페이지</h1>
  </div>
</template>

<script setup></script>

<style scoped></style>
